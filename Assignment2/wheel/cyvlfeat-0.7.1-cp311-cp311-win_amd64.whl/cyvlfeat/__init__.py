"""""" # start delvewheel patch
def _delvewheel_patch_1_13_2():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'cyvlfeat.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_13_2()
del _delvewheel_patch_1_13_2
# end delvewheel patch

import cyvlfeat.fisher
import cyvlfeat.generic
import cyvlfeat.gmm
import cyvlfeat.hog
import cyvlfeat.kmeans
import cyvlfeat.quickshift
import cyvlfeat.sift


from ._version import __version__
del _version
